Shapefile for Coastal Zone Management Program counties of the United States and its territories, 2009

shapefile components:
  CZMP_counties_2009.dbf
  CZMP_counties_2009.prj
  CZMP_counties_2009.sbn
  CZMP_counties_2009.sbx
  CZMP_counties_2009.shp
  CZMP_counties_2009.shx

metadata:
  CZMP_counties_2009.shp.xml
  CZMP_counties_2009.txt
  
browse graphic:
  CZMP_counties_2009.gif
  
Google Earth visualization:
  CZMP_counties_2009.kmz
  
spreadsheet for creating supplemental attributes:
  CZMP_counties_2009_supplement.xlsx
  
  